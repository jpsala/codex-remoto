#!/bin/bash
# Remote Mac setup: only the scoped proxy key is requested; never a profile.
set +x
set -euo pipefail
umask 077
SERVICE='dev.jpsala.llm-proxy.remoto'
ACCOUNT='REMOTO'
KIT="$(cd -- "$(dirname -- "$0")" && pwd -P)"
PRIVATE_ROOT="$HOME/.config/llm-proxy-remoto"
CODEX_ROOT="${CODEX_HOME:-$HOME/.codex}"
STAGE=''
KEY_CHANGED=0
FILES_CHANGED=0
OLD_KEY=''
KEY=''

notice() {
    # Message is passed as data, never interpolated into AppleScript source.
    /usr/bin/osascript - "$1" <<'APPLESCRIPT' >/dev/null 2>&1 || true
on run argv
    display dialog (item 1 of argv) with title "Codex REMOTO" buttons {"OK"} default button "OK"
end run
APPLESCRIPT
}

save_key() {
    # Feed the key to security's stdin, avoiding a credential in process argv.
    # Key characters were validated before constructing this single command.
    printf 'add-generic-password -U -a REMOTO -s dev.jpsala.llm-proxy.remoto -T /usr/bin/security -w %s\n' "$1" |
        /usr/bin/security -i >/dev/null 2>&1
}

configure() {
    /usr/bin/osascript -l JavaScript "$KIT/configure.js" "$1" "$KIT" "$STAGE" "$CODEX_ROOT" "$PRIVATE_ROOT"
}

cleanup() {
    local code=$?
    trap - EXIT INT TERM
    if [ "$FILES_CHANGED" -eq 1 ]; then
        configure rollback >/dev/null 2>&1 || printf '%s\n' 'Restauracion pendiente: conservar el respaldo para JP.' >&2
    fi
    if [ "$KEY_CHANGED" -eq 1 ]; then
        if [ -n "$OLD_KEY" ]; then
            save_key "$OLD_KEY" || printf '%s\n' 'No se pudo restaurar la clave anterior del Llavero.' >&2
        else
            /usr/bin/security delete-generic-password -a "$ACCOUNT" -s "$SERVICE" >/dev/null 2>&1 || true
        fi
    fi
    unset KEY OLD_KEY stored_key
    if [ "$code" -ne 0 ]; then
        printf '%s\n' 'No se completo la configuracion. La anterior se conserva; el respaldo queda en la carpeta privada.' >&2
    fi
    exit "$code"
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM

if [ "$(/usr/bin/uname -s)" != 'Darwin' ]; then
    printf '%s\n' 'Este configurador es para macOS.' >&2
    exit 1
fi
if ! command -v codex >/dev/null 2>&1 && [ ! -d /Applications/Codex.app ] && [ ! -d "$HOME/Applications/Codex.app" ]; then
    notice 'Primero instala la app oficial de Codex. Despues volve a abrir Configurar-Remoto.command.'
    exit 1
fi
if [ ! -f "$KIT/configure.js" ] || [ ! -f "$KIT/models.json" ] || [ ! -f "$KIT/policy.json" ]; then
    notice 'Faltan archivos. Extrae el ZIP completo y volve a abrir Configurar-Remoto.command.'
    exit 1
fi
case "$CODEX_ROOT" in /*) ;; *) notice 'CODEX_HOME necesita una ruta absoluta. JP debe revisar esa configuracion.'; exit 1 ;; esac
if [ -L "$PRIVATE_ROOT" ] || [ -L "$CODEX_ROOT/config.toml" ]; then
    notice 'La configuracion usa un enlace a otra carpeta. Pedile a JP que la revise antes de cambiarla.'
    exit 1
fi
/bin/mkdir -p "$PRIVATE_ROOT" "$CODEX_ROOT"
/bin/chmod 700 "$PRIVATE_ROOT"
STAGE="$(/usr/bin/mktemp -d "$PRIVATE_ROOT/rollback-$(/bin/date -u +%Y%m%dT%H%M%SZ)-XXXXXX")"
/bin/chmod 700 "$STAGE"

if ! KEY=$(/usr/bin/osascript <<'APPLESCRIPT'
set resultDialog to display dialog "Pega la clave del acceso REMOTO. Se guarda en el Llavero y no se vuelve a pedir al usar Codex." default answer "" with hidden answer with title "Codex REMOTO" buttons {"Cancelar", "Configurar"} default button "Configurar" cancel button "Cancelar"
return text returned of resultDialog
APPLESCRIPT
); then
    exit 130
fi
if [ -z "$KEY" ] || [ "${#KEY}" -gt 1024 ] || [[ ! "$KEY" =~ ^[a-zA-Z0-9_-]+$ ]]; then
    notice 'La clave esta vacia o tiene espacios/caracteres inesperados. Pedile a JP la clave del proxy para REMOTO.'
    exit 1
fi

# The token never appears in curl arguments, shell history or a config file.
if ! printf 'url = "https://llm-proxy.jpsala.dev/v1/models"\nheader = "Authorization: Bearer %s"\n' "$KEY" |
    /usr/bin/curl --silent --show-error --fail --connect-timeout 10 --max-time 25 --proto '=https' --config - --output "$STAGE/available-models.json"; then
    notice 'El VPS no respondio o no acepto la clave. No se cambio Codex. Revisa la conexion y la clave de REMOTO.'
    exit 1
fi
if ! configure prepare; then
    notice 'No se pudo preparar Codex. Revisa el mensaje de esta ventana con JP; la configuracion anterior se conserva.'
    exit 1
fi
if OLD_KEY=$(/usr/bin/security find-generic-password -a "$ACCOUNT" -s "$SERVICE" -w 2>/dev/null); then
    if [ -z "$OLD_KEY" ] || [[ ! "$OLD_KEY" =~ ^[a-zA-Z0-9_-]+$ ]]; then
        notice 'El Llavero tiene una entrada REMOTO inesperada. Pedile a JP que la revise.'
        exit 1
    fi
else
    # errSecItemNotFound (-25300) maps to exit status 44. Other failures may
    # mean the existing item is locked; never overwrite it without a rollback.
    lookup_status=$?
    if [ "$lookup_status" -ne 44 ]; then
        notice 'No se pudo leer el Llavero. Desbloquealo y volve a ejecutar el configurador.'
        exit 1
    fi
fi
KEY_CHANGED=1
if ! save_key "$KEY"; then
    notice 'No se pudo guardar la clave en el Llavero. Desbloquea el Llavero y volve a ejecutar el configurador.'
    exit 1
fi
stored_key=$(/usr/bin/security find-generic-password -a "$ACCOUNT" -s "$SERVICE" -w 2>/dev/null || true)
if [ "$stored_key" != "$KEY" ]; then
    notice 'No se pudo verificar la clave en el Llavero. La configuracion anterior se conserva.'
    exit 1
fi
FILES_CHANGED=1
if ! configure commit; then
    notice 'No se pudo guardar Codex. Se intentara restaurar la configuracion anterior; pedile a JP que revise el respaldo.'
    exit 1
fi
/bin/chmod 600 "$CODEX_ROOT/config.toml" "$PRIVATE_ROOT/models.json"
FILES_CHANGED=0
KEY_CHANGED=0
unset KEY OLD_KEY stored_key
printf '%s\n' 'Listo: Codex REMOTO. Luna y Sol hasta GPT-6.1 Sol, low/medium/high, sin Astra.' 'Cierra Codex, volve a abrirlo y crea un chat nuevo.'
notice 'Listo. Cierra Codex y volve a abrirlo. GPT-6.1 Sol arranca en medium. Podes elegir Luna, Sol y esfuerzos desde low hasta high; Astra queda excluido.'
