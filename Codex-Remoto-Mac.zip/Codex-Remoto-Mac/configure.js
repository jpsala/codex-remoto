// REMOTO macOS JXA entry point. Pure functions run in the local verification.
var REMOTO_MODEL = 'gpt-6.1-sol';
var REMOTO_PROVIDER = 'llm-vps-remoto';
var REMOTO_SERVICE = 'dev.jpsala.llm-proxy.remoto';
var BEGIN = '# BEGIN LLM-PROXY REMOTO';
var END = '# END LLM-PROXY REMOTO';

function remotoCatalog(catalog, available, policy) {
    var expected = policy && Array.isArray(policy.models) ? policy.models.slice().sort().join(',') : '';
    var ids = available && Array.isArray(available.data) ? available.data.map(function (model) { return model.id; }).sort().join(',') : '';
    if (!expected || ids !== expected) {
        throw new Error('La clave no corresponde a REMOTO. Pedile a JP la clave de REMOTO.');
    }
    var models = catalog && Array.isArray(catalog.models) ? catalog.models : [];
    if (models.map(function (model) { return model.slug; }).sort().join(',') !== expected) throw new Error('El kit esta incompleto. Volver a extraer el ZIP.');
    return { models: models.map(function (original) {
        var model = JSON.parse(JSON.stringify(original));
        model.supported_reasoning_levels = (model.supported_reasoning_levels || []).filter(function (level) {
            return level.effort === 'low' || level.effort === 'medium' || level.effort === 'high';
        });
        if (model.supported_reasoning_levels.map(function (level) { return level.effort; }).sort().join(',') !== 'high,low,medium') {
            throw new Error('El catalogo no tiene los esfuerzos de REMOTO. Pedile a JP un kit actualizado.');
        }
        if (['low', 'medium', 'high'].indexOf(model.default_reasoning_level) === -1) model.default_reasoning_level = 'medium';
        model.use_responses_lite = false;
        return model;
    }) };
}

function remotoConfig(original, catalogPath) {
    if (typeof original !== 'string' || /\u0000/.test(original)) throw new Error('No se pudo leer la configuracion existente.');
    // Avoid interpreting multiline TOML strings as tables or root settings.
    if (original.indexOf('"""') !== -1 || original.indexOf("'''") !== -1) {
        throw new Error('La configuracion usa texto TOML multilinea. JP debe integrar el proveedor conservando ese texto.');
    }
    var clean = original.replace(/^# BEGIN LLM-PROXY REMOTO\r?\n[\s\S]*?^# END LLM-PROXY REMOTO(?:\r?\n|$)/gm, '');
    if (clean.indexOf(BEGIN) !== -1 || clean.indexOf(END) !== -1 ||
        /^[ \t]*\[[ \t]*model_providers[ \t]*\.[ \t]*(?:llm-vps-remoto|"llm-vps-remoto"|'llm-vps-remoto')[ \t]*(?:\]|\.)/m.test(clean)) {
        throw new Error('Ya existe una configuracion REMOTO ajena al kit. Pedile a JP que la revise.');
    }
    var table = /^[ \t]*\[[ \t]*\[?[ \t]*[A-Za-z_"'][^\r\n]*\][ \t]*(?:#.*)?\r?$/m.exec(clean);
    var root = table ? clean.slice(0, table.index) : clean;
    var tables = table ? clean.slice(table.index) : '';
    ['model', 'model_provider', 'model_reasoning_effort', 'model_catalog_json'].forEach(function (name) {
        var keyPattern = new RegExp('^[ \\t]*(?:' + name + '|"' + name + '"|\'' + name + '\')[ \\t]*=', 'm');
        var linePattern = new RegExp('^[ \\t]*(?:' + name + '|"' + name + '"|\'' + name + '\')[ \\t]*=.*(?:\\r?\\n|$)', 'gm');
        if (keyPattern.test(root)) root = root.replace(linePattern, '');
    });
    var layer = 'model_provider = "' + REMOTO_PROVIDER + '"\n' +
        'model = "' + REMOTO_MODEL + '"\nmodel_reasoning_effort = "medium"\n' +
        'model_catalog_json = ' + JSON.stringify(catalogPath) + '\n';
    var provider = [BEGIN, '[model_providers.' + REMOTO_PROVIDER + ']', 'name = "LLM-proxy REMOTO"',
        'base_url = "https://llm-proxy.jpsala.dev/v1"', 'wire_api = "responses"', 'supports_websockets = false', '',
        '[model_providers.' + REMOTO_PROVIDER + '.auth]', 'command = "/usr/bin/security"',
        'args = ["find-generic-password", "-a", "REMOTO", "-s", "' + REMOTO_SERVICE + '", "-w"]',
        'timeout_ms = 30000', 'refresh_interval_ms = 300000', END, ''].join('\n');
    return layer + root.replace(/\s+$/, '') + '\n\n' + tables.replace(/\s+$/, '') + '\n\n' + provider;
}

function run(args) {
    ObjC.import('Foundation');
    var fm = $.NSFileManager.defaultManager;
    var mode = args[0], kit = args[1], stage = args[2], codexRoot = args[3], privateRoot = args[4];
    var configPath = codexRoot + '/config.toml', catalogPath = privateRoot + '/models.json';
    function exists(path) { return Boolean(fm.fileExistsAtPath($(path))); }
    function read(path) {
        var error = Ref();
        var value = $.NSString.stringWithContentsOfFileEncodingError($(path), $.NSUTF8StringEncoding, error);
        if (!value || value.isNil()) throw new Error('No se pudo leer un archivo de configuracion.');
        return ObjC.unwrap(value);
    }
    function write(path, text) {
        var error = Ref();
        if (!$(text).writeToFileAtomicallyEncodingError($(path), true, $.NSUTF8StringEncoding, error)) {
            throw new Error('No se pudo guardar la configuracion.');
        }
    }
    function remove(path) { if (exists(path) && !fm.removeItemAtPathError($(path), Ref())) throw new Error('No se pudo restaurar un archivo nuevo.'); }
    if (mode === 'prepare') {
        var original = exists(configPath) ? read(configPath) : '';
        var catalog = remotoCatalog(JSON.parse(read(kit + '/models.json')), JSON.parse(read(stage + '/available-models.json')), JSON.parse(read(kit + '/policy.json')));
        var configured = remotoConfig(original, catalogPath);
        var state = { config_existed: exists(configPath), catalog_existed: exists(catalogPath) };
        if (state.config_existed) write(stage + '/original-config.toml', original);
        if (state.catalog_existed) write(stage + '/original-models.json', read(catalogPath));
        write(stage + '/prepared-models.json', JSON.stringify(catalog, null, 2) + '\n');
        write(stage + '/prepared-config.toml', configured);
        write(stage + '/restore.json', JSON.stringify(state) + '\n');
    } else if (mode === 'commit') {
        write(catalogPath, read(stage + '/prepared-models.json'));
        write(configPath, read(stage + '/prepared-config.toml'));
    } else if (mode === 'rollback') {
        if (!exists(stage + '/restore.json')) return;
        var previous = JSON.parse(read(stage + '/restore.json'));
        if (previous.catalog_existed) write(catalogPath, read(stage + '/original-models.json')); else remove(catalogPath);
        if (previous.config_existed) write(configPath, read(stage + '/original-config.toml')); else remove(configPath);
    } else {
        throw new Error('Operacion de configuracion desconocida.');
    }
}
