@echo off
setlocal
for %%F in (setup.ps1 gateway-key.ps1 models.json policy.json) do if not exist "%~dp0%%F" goto incomplete
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1"
set "setupExit=%errorlevel%"
if not "%setupExit%"=="0" echo No se completo la configuracion. Revisar el mensaje anterior.
pause
exit /b %setupExit%

:incomplete
echo.
echo PRIMERO EXTRAE TODO EL ZIP
echo.
echo Faltan archivos junto al configurador.
echo Esto puede pasar si lo abriste desde WinRAR o dentro del ZIP.
echo.
echo 1. Cierra esta ventana y la ventana de WinRAR.
echo 2. Busca Codex-Remoto-Windows.zip en Descargas.
echo 3. Haz clic derecho y elige Extraer todo, o Extraer en WinRAR.
echo 4. Abre la carpeta extraida y luego Configurar-Remoto.cmd.
echo.
echo No se cambio la configuracion de Codex.
pause
exit /b 1
