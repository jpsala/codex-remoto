[CmdletBinding()]
param([switch]$CLIOnly)
$ErrorActionPreference = 'Stop'
if ($PSVersionTable.PSVersion.Major -le 5) {
    $env:PSModulePath = [IO.Path]::Combine($env:SystemRoot, 'System32\WindowsPowerShell\v1.0\Modules')
}
$gatewayURL = 'https://llm-proxy.jpsala.dev/v1'
$hasCLI = $null -ne (Get-Command codex -ErrorAction SilentlyContinue)
$hasApp = (Test-Path -Path (Join-Path $env:LOCALAPPDATA 'OpenAI/Codex/bin/*/codex.exe') -PathType Leaf) -or
    (Test-Path -LiteralPath (Join-Path $env:LOCALAPPDATA 'Programs/OpenAI/Codex/bin/codex.exe') -PathType Leaf)
if (-not $hasCLI -and -not $hasApp) { throw 'Primero instalar Codex CLI o la app oficial. Ver LEEME.txt.' }
$codexRoot = if ($env:CODEX_HOME) { $env:CODEX_HOME } else { Join-Path $env:USERPROFILE '.codex' }
$configPath = Join-Path $codexRoot 'config.toml'
$profilePath = Join-Path $codexRoot 'llm-vps-remoto.config.toml'
$privateRoot = Join-Path $env:USERPROFILE '.config/llm-proxy-remoto'
$sourceCatalog = Join-Path $PSScriptRoot 'models.json'
$sourcePolicy = Join-Path $PSScriptRoot 'policy.json'
if (-not (Test-Path -LiteralPath $sourceCatalog -PathType Leaf) -or -not (Test-Path -LiteralPath $sourcePolicy -PathType Leaf)) { throw 'Faltan archivos. Extraer el ZIP completo.' }
$catalog = Get-Content -LiteralPath $sourceCatalog -Raw | ConvertFrom-Json
$policy = Get-Content -LiteralPath $sourcePolicy -Raw | ConvertFrom-Json
$expectedModels = @($policy.models | Sort-Object) -join ','
if ((@($catalog.models.slug | Sort-Object) -join ',') -ne $expectedModels) { throw 'Catalogo REMOTO incompleto.' }
foreach ($modelInfo in $catalog.models) {
    $modelInfo.supported_reasoning_levels = @($modelInfo.supported_reasoning_levels | Where-Object { $_.effort -in @('low', 'medium', 'high') })
    if ((@($modelInfo.supported_reasoning_levels.effort | Sort-Object) -join ',') -ne 'high,low,medium') {
        throw 'Faltan los esfuerzos low/medium/high. Pedir un kit actualizado.'
    }
    if ($modelInfo.default_reasoning_level -notin @('low', 'medium', 'high')) { $modelInfo.default_reasoning_level = 'medium' }
    $modelInfo.use_responses_lite = $false
}
$secretPointer = [IntPtr]::Zero
$previousFiles = @{}
$changesStarted = $false
function Write-AtomicText([string]$Path, [string]$Value) {
    $temporary = $Path + '.llm-' + [Guid]::NewGuid().ToString('N') + '.tmp'
    try {
        [IO.File]::WriteAllText($temporary, $Value, (New-Object Text.UTF8Encoding($false)))
        if ([IO.File]::Exists($Path)) {
            [IO.File]::Replace($temporary, $Path, [System.Management.Automation.Language.NullString]::Value)
        } else { [IO.File]::Move($temporary, $Path) }
    } finally {
        if ([IO.File]::Exists($temporary)) { Remove-Item -LiteralPath $temporary }
    }
}
try {
    $secureKey = Read-Host 'Pegar la clave del acceso REMOTO (entrada oculta)' -AsSecureString
    $secretPointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureKey)
    $key = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($secretPointer)
    if ([string]::IsNullOrWhiteSpace($key) -or $key -match '\s') { throw 'Clave vacia o con espacios.' }
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $response = Invoke-RestMethod -Uri ($gatewayURL + '/models') -Headers @{ Authorization = 'Bearer ' + $key } -TimeoutSec 15
    } catch { throw 'El VPS no acepto la clave o no respondio. No se cambio Codex.' }
    $ids = @($response.data | ForEach-Object { $_.id })
    if ((@($ids | Sort-Object) -join ',') -ne $expectedModels) { throw 'La clave no corresponde a REMOTO. No se cambio Codex.' }
    New-Item -ItemType Directory -Path $codexRoot -Force | Out-Null
    $privateExisted = Test-Path -LiteralPath $privateRoot -PathType Container
    if ($privateExisted -and ((Get-Item -LiteralPath $privateRoot).Attributes -band [IO.FileAttributes]::ReparsePoint)) {
        throw 'La carpeta privada es un enlace. Revisar antes de guardar una clave.'
    }
    New-Item -ItemType Directory -Path $privateRoot -Force | Out-Null
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent().User
    if (-not $privateExisted) {
        $acl = New-Object Security.AccessControl.DirectorySecurity
        $acl.SetAccessRuleProtection($true, $false)
        $acl.SetOwner($identity)
        foreach ($sid in @($identity, [Security.Principal.SecurityIdentifier]'S-1-5-18')) {
            $rule = New-Object Security.AccessControl.FileSystemAccessRule($sid, 'FullControl', 'ContainerInherit,ObjectInherit', 'None', 'Allow')
            $acl.AddAccessRule($rule)
        }
        [IO.Directory]::SetAccessControl($privateRoot, $acl)
    }
    $currentAcl = Get-Acl -LiteralPath $privateRoot
    $allowedSids = @($identity.Value, 'S-1-5-18')
    $rules = @($currentAcl.Access)
    $ruleSids = @($rules | ForEach-Object { $_.IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value })
    if (-not $currentAcl.AreAccessRulesProtected -or $rules.Count -ne 2 -or
        @($ruleSids | Where-Object { $_ -notin $allowedSids }).Count -or
        @($rules | Where-Object { $_.AccessControlType -ne 'Allow' -or $_.FileSystemRights -ne 'FullControl' }).Count) {
        throw 'La carpeta privada tiene permisos inesperados. Revisar antes de guardar una clave.'
    }
    $oldConfig = if ([IO.File]::Exists($configPath)) { [IO.File]::ReadAllText($configPath) } else { '' }
    if ($oldConfig.Contains('"""') -or $oldConfig.Contains("'''")) {
        throw 'La configuracion usa texto TOML multilinea. JP debe integrar REMOTO conservando ese texto.'
    }
    $clean = [regex]::Replace($oldConfig, '(?ms)^# BEGIN LLM-PROXY REMOTO\r?\n.*?^# END LLM-PROXY REMOTO(?:\r?\n|$)', '')
    if ($clean.Contains('# BEGIN LLM-PROXY REMOTO') -or $clean.Contains('# END LLM-PROXY REMOTO') -or
        $clean -match '(?m)^[ \t]*\[[ \t]*model_providers[ \t]*\.[ \t]*(?:llm-vps-remoto|"llm-vps-remoto"|''llm-vps-remoto'')[ \t]*(?:\]|\.)') {
        throw 'Ya existe un proveedor REMOTO ajeno al kit. Pedir a JP que lo revise.'
    }
    $table = [regex]::Match($clean, '(?m)^[ \t]*\[[ \t]*\[?[ \t]*[A-Za-z_"''][^\r\n]*\][ \t]*(?:#.*)?\r?$')
    $root = if ($table.Success) { $clean.Substring(0, $table.Index) } else { $clean }
    $tables = if ($table.Success) { $clean.Substring($table.Index) } else { '' }
    foreach ($name in @('model_provider', 'model_catalog_json', 'model', 'model_reasoning_effort')) {
        $pattern = '(?m)^[ \t]*(?:' + $name + '|"' + $name + '"|''' + $name + ''')[ \t]*=.*(?:\r?\n|$)'
        $root = [regex]::Replace($root, $pattern, '')
    }
    # JSON strings are valid TOML basic strings, including spaces, quotes and backslashes.
    $catalogLiteral = ConvertTo-Json -InputObject (Join-Path $privateRoot 'models.json') -Compress
    $shellLiteral = ConvertTo-Json -InputObject (Join-Path $env:SystemRoot 'System32/WindowsPowerShell/v1.0/powershell.exe') -Compress
    $helperLiteral = ConvertTo-Json -InputObject (Join-Path $privateRoot 'gateway-key.ps1') -Compress
    $provider = @"
# BEGIN LLM-PROXY REMOTO
[model_providers.llm-vps-remoto]
name = "LLM-proxy REMOTO"
base_url = "$gatewayURL"
wire_api = "responses"
supports_websockets = false

[model_providers.llm-vps-remoto.auth]
command = $shellLiteral
args = ["-NoLogo", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", $helperLiteral]
timeout_ms = 10000
refresh_interval_ms = 300000
# END LLM-PROXY REMOTO
"@
    $layer = "model_provider = `"llm-vps-remoto`"`r`nmodel = `"gpt-6.1-sol`"`r`nmodel_reasoning_effort = `"medium`"`r`nmodel_catalog_json = $catalogLiteral`r`n"
    $stamp = (Get-Date).ToUniversalTime().ToString('yyyyMMddTHHmmssfffZ')
    $backupRoot = Join-Path $privateRoot ('rollback-' + $stamp)
    New-Item -ItemType Directory -Path $backupRoot | Out-Null
    $files = @($configPath, $profilePath) + @('gateway-key.ps1', 'models.json', 'key-REMOTO.dpapi' | ForEach-Object { Join-Path $privateRoot $_ })
    foreach ($path in $files) {
        $previousFiles[$path] = [IO.File]::Exists($path)
        if ($previousFiles[$path]) { Copy-Item -LiteralPath $path -Destination (Join-Path $backupRoot ([IO.Path]::GetFileName($path))) }
    }
    $changesStarted = $true
    $utf8 = New-Object Text.UTF8Encoding($false)
    [IO.File]::WriteAllText((Join-Path $privateRoot 'key-REMOTO.dpapi'), ($secureKey | ConvertFrom-SecureString), $utf8)
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'gateway-key.ps1') -Destination (Join-Path $privateRoot 'gateway-key.ps1') -Force
    [IO.File]::WriteAllText((Join-Path $privateRoot 'models.json'), ($catalog | ConvertTo-Json -Depth 100), $utf8)
    Write-AtomicText $profilePath ($layer + "`r`n" + $provider + "`r`n")
    if (-not $CLIOnly) {
        Write-AtomicText $configPath ($layer + $root.TrimEnd() + "`r`n`r`n" + $tables.TrimEnd() + "`r`n`r`n" + $provider + "`r`n")
    }
    Write-Host 'Listo: Codex REMOTO. Luna y Sol hasta GPT-6.1 Sol, low/medium/high, sin Astra.'
    Write-Host 'Cerrar Codex, volver a abrirlo y crear un chat nuevo.'
    Write-Host ('Respaldo privado: ' + $backupRoot)
    if ($CLIOnly) { Write-Host 'CLI: codex -p llm-vps-remoto' }
} catch {
    if ($changesStarted) {
        foreach ($path in $previousFiles.Keys) {
            if ($CLIOnly -and $path -eq $configPath) { continue }
            if ($previousFiles[$path]) {
                Copy-Item -LiteralPath (Join-Path $backupRoot ([IO.Path]::GetFileName($path))) -Destination $path -Force
            } elseif (Test-Path -LiteralPath $path -PathType Leaf) { Remove-Item -LiteralPath $path }
        }
        Write-Host 'Se restauro la configuracion anterior despues del error.'
    }
    throw
} finally {
    if ($secretPointer -ne [IntPtr]::Zero) { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($secretPointer) }
    $key = $null
}
