# Codex invokes this helper and privately captures its stdout.
$ErrorActionPreference = 'Stop'
if ($PSVersionTable.PSVersion.Major -le 5) {
    $env:PSModulePath = [IO.Path]::Combine($env:SystemRoot, 'System32\WindowsPowerShell\v1.0\Modules')
}
$secretPointer = [IntPtr]::Zero
try {
    $encrypted = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'key-JP.dpapi') -Raw
    $secure = $encrypted | ConvertTo-SecureString
    $secretPointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
    $key = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($secretPointer)
    if ([string]::IsNullOrWhiteSpace($key) -or $key -match '\s') { throw 'Missing key' }
    [Console]::Out.Write($key)
} catch {
    [Console]::Error.WriteLine('No se pudo leer la clave JP. Volver a ejecutar Configurar-JP.cmd con este usuario de Windows.')
    exit 1
} finally {
    if ($secretPointer -ne [IntPtr]::Zero) { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($secretPointer) }
    $key = $null
}
